// This file is what Vercel will run
const app = require('../server');

module.exports = app;
